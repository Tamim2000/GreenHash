$(document).ready(function(){
    

	// Preloader-----------
		setTimeout(function(){
			$('.loader-bg').fadeToggle()
		},2000);

/*==============================================================*/
		// header scroll sticky
		/*==============================================================*/
const $header = document.querySelectorAll('header')[0];

let lastKnownScrollTop = 0;
let headerTop = 0;
let headerHeight = $header.offsetHeight;

window.addEventListener('scroll', function(event){
  console.log( event.target.scrollingElement.scrollTop )
  console.log(event)
  let scrollTop = event.target.scrollingElement.scrollTop;
  let offset = scrollTop - lastKnownScrollTop;
  headerTop-= offset;
  headerTop = headerTop > 0? 0: headerTop;
  headerTop = headerTop < -1 * headerHeight? -1 * headerHeight: headerTop;
  $header.style.transform = `translateY(${headerTop}px)`;
  lastKnownScrollTop = scrollTop;
});
/*==============================================================*/
		// banner-section slidder and animation
		/*==============================================================*/
		var $bannerSlider = jQuery('.banner-slider');
		var $bannerFirstSlide = $('div.banner-slide:first-child');

		$bannerSlider.on('init', function(e, slick) {
			var $firstAnimatingElements = $bannerFirstSlide.find('[data-animation]');
			slideanimate($firstAnimatingElements);
		});
		$bannerSlider.on('beforeChange', function(e, slick, currentSlide, nextSlide) {
			var $animatingElements = $('div.slick-slide[data-slick-index="' + nextSlide + '"]').find('[data-animation]');
			slideanimate($animatingElements);
		});
		$bannerSlider.slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: true,
			prevArrow:'<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
			nextArrow:'<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
			dots: false,
			swipe: true,
			// autoplay:true,
			autoplaySpeed:7000,
			responsive: [
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					autoplay: false,
					autoplaySpeed: 4000,
					swipe: true,
				}
			}
			]
		});
		function slideanimate(elements) {
			var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
			elements.each(function() {
				var $this = $(this);
				var $animationDelay = $this.data('delay');
				var $animationType = 'animated ' + $this.data('animation');
				$this.css({
					'animation-delay': $animationDelay,
					'-webkit-animation-delay': $animationDelay
				});
				$this.addClass($animationType).one(animationEndEvents, function() {
					$this.removeClass($animationType);
				});
			});
		}
/*==============================================================*/
		// service section slider active
		/*==============================================================*/
		$('.server-slide').slick({
			slidesToShow: 3,
			slidesToScroll: 3,
			autoplay: true,
			centerPadding: '0px',
			centerMode: true,
			autoplaySpeed: 5000,
			prevArrow:'<button type="button" class="slick-prev"><i class="fas fa-arrow-left"></i></button>',
			nextArrow:'<button type="button" class="slick-next"><i class="fas fa-arrow-right"></i></button>',
			responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 2,
					slidesToScroll: 3,
					infinite: true,
					dots: false
				  }
				},
				{
				  breakpoint: 767,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 2
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
				// You can unslick at a given breakpoint now by adding:
				// settings: "unslick"
				// instead of a settings object
			  ]
		  });

//counter avctivation---------------------
$('.counter').counterUp({
	delay: 10,
	time: 1500
});
//popup video activation-------------------------
$('.popup-link').magnificPopup({
	type: 'iframe'
	// other options
  });
//   product slider and team slider -----
$('.slide-active').slick({
	slidesToShow: 4,
	slidesToScroll: 3,
	dots:true,
	// autoplay: true,
	centerPadding: '0px',
	autoplaySpeed: 5000,
	prevArrow:'<button type="button" class="slick-prev"><i class="fas fa-arrow-left"></i></button>',
	nextArrow:'<button type="button" class="slick-next"><i class="fas fa-arrow-right"></i></button>',
	responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 3,
			slidesToScroll: 3,
			infinite: true,
			dots: true
		  }
		},
		{
		  breakpoint: 767,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 2
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]


  });
  //testimonial active--------------------
$('.slide-testimonial').slick({
	slidesToShow: 3,
	slidesToScroll: 1,
	dots:true,
	autoplay: true,
	centerMode: true,
	centerPadding: '0px',
	autoplaySpeed: 5000,
	prevArrow:'<button type="button" class="slick-prev"><i class="fas fa-arrow-left"></i></button>',
	nextArrow:'<button type="button" class="slick-next"><i class="fas fa-arrow-right"></i></button>',
	responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 3,
			infinite: true,
			dots: true
		  }
		},
		{
		  breakpoint: 767,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 2
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]

  });
  //brand-logo active--------------------
  $('.brand-slide').slick({
	slidesToShow: 6,
	slidesToScroll: 3,
	dots:false,
	arrows:false,
	autoplay: true,
	autoplaySpeed: 3000,
	responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 4,
			slidesToScroll: 3,
			infinite: true,
			dots: false
		  }
		},
		{
		  breakpoint: 767,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 2
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 1
		  }
		}
	  ]

  });

	// scrollTop--------------------
	$('.go-top').hide(0)
	$(window).scroll(function(){
	if($(this).scrollTop() > 100){
		$('.go-top').fadeIn(200);      
	} else {
		$('.go-top').fadeOut(300);
	}
	});
	$('.go-top').click(function() {
	event.preventDefault();
	$('html , body').animate({scrollTop: 0}, 1000);
	});






});